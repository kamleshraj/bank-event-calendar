import 'bootstrap/dist/css/bootstrap.min.css'
import MainEventCalendar from "./MainEventCalendar";
import './App.css'

function App() {
  return (
    <div className="container">
      <MainEventCalendar/>
    </div>
  );
}

export default App;
